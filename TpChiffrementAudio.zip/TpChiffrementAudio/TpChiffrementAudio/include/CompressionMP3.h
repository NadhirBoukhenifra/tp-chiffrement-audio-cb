#ifndef COMPRESSIONMP3_H
#define COMPRESSIONMP3_H


class CompressionMP3
{
    public:
        CompressionMP3();
        virtual ~CompressionMP3();

    protected:

    private:
};

#endif // COMPRESSIONMP3_H
